package com.ibm.proyectos.restip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestIpApplicationTests {

	@Test
	void contextLoads() {
	}

}
